package estagio.joao.connect_plc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
